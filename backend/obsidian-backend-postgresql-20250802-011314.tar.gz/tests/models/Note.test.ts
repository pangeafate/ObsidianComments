// Mock the database connection for testing
const mockQuery = jest.fn();
jest.mock('../../src/db/connection', () => ({
  pool: {
    query: mockQuery,
  },
}));

import { NoteModel, NoteData } from '../../src/db/models/Note';

describe('NoteModel', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('create', () => {
    it('should create a new note and return note data', async () => {
      // RED: Write test that should fail
      const mockNoteData = {
        shareId: 'test123',
        content: '# Test Note\n\nThis is a test.',
        ownerId: 'user123'
      };

      const mockDbResponse = {
        rows: [{
          id: 1,
          share_id: 'test123',
          content: '# Test Note\n\nThis is a test.',
          owner_id: 'user123',
          created_at: new Date('2024-01-01T00:00:00Z'),
          updated_at: new Date('2024-01-01T00:00:00Z'),
          version: 1,
          is_active: true
        }]
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.create(mockNoteData);

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining('INSERT INTO shares'),
        ['test123', '# Test Note\n\nThis is a test.', 'user123']
      );

      expect(result).toEqual({
        id: 1,
        shareId: 'test123',
        content: '# Test Note\n\nThis is a test.',
        ownerId: 'user123',
        createdAt: new Date('2024-01-01T00:00:00Z'),
        updatedAt: new Date('2024-01-01T00:00:00Z'),
        version: 1,
        isActive: true
      });
    });

    it('should handle null ownerId', async () => {
      const mockNoteData = {
        shareId: 'test456',
        content: '# Anonymous Note',
      };

      const mockDbResponse = {
        rows: [{
          id: 2,
          share_id: 'test456',
          content: '# Anonymous Note',
          owner_id: null,
          created_at: new Date('2024-01-01T00:00:00Z'),
          updated_at: new Date('2024-01-01T00:00:00Z'),
          version: 1,
          is_active: true
        }]
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.create(mockNoteData);

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining('INSERT INTO shares'),
        ['test456', '# Anonymous Note', null]
      );

      expect(result.ownerId).toBeNull();
    });

    it('should throw error when database fails', async () => {
      const mockNoteData = {
        shareId: 'test789',
        content: '# Failed Note',
      };

      mockQuery.mockRejectedValueOnce(new Error('Database connection failed'));

      await expect(NoteModel.create(mockNoteData)).rejects.toThrow('Failed to create shared note');
    });
  });

  describe('getByShareId', () => {
    it('should return note data when found', async () => {
      const mockDbResponse = {
        rows: [{
          id: 1,
          share_id: 'existing123',
          content: '# Existing Note',
          owner_id: 'user123',
          created_at: new Date('2024-01-01T00:00:00Z'),
          updated_at: new Date('2024-01-01T01:00:00Z'),
          version: 2,
          is_active: true
        }]
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.getByShareId('existing123');

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining('SELECT * FROM shares'),
        ['existing123']
      );

      expect(result).toEqual({
        id: 1,
        shareId: 'existing123',
        content: '# Existing Note',
        ownerId: 'user123',
        createdAt: new Date('2024-01-01T00:00:00Z'),
        updatedAt: new Date('2024-01-01T01:00:00Z'),
        version: 2,
        isActive: true
      });
    });

    it('should return null when note not found', async () => {
      const mockDbResponse = {
        rows: []
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.getByShareId('nonexistent');

      expect(result).toBeNull();
    });

    it('should throw error when database fails', async () => {
      mockQuery.mockRejectedValueOnce(new Error('Database error'));

      await expect(NoteModel.getByShareId('test')).rejects.toThrow('Failed to fetch shared note');
    });
  });

  describe('update', () => {
    it('should update note and increment version', async () => {
      const mockDbResponse = {
        rows: [{
          id: 1,
          share_id: 'update123',
          content: '# Updated Note',
          owner_id: 'user123',
          created_at: new Date('2024-01-01T00:00:00Z'),
          updated_at: new Date('2024-01-01T02:00:00Z'),
          version: 3,
          is_active: true
        }],
        rowCount: 1
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.update('update123', '# Updated Note', 'user123');

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining('UPDATE shares'),
        ['# Updated Note', 'update123', 'user123']
      );

      expect(result.version).toBe(3);
      expect(result.content).toBe('# Updated Note');
    });

    it('should throw error when note not found or access denied', async () => {
      const mockDbResponse = {
        rows: [],
        rowCount: 0
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      await expect(NoteModel.update('nonexistent', 'content', 'user')).rejects.toThrow('Note not found or access denied');
    });
  });

  describe('delete', () => {
    it('should soft delete note and return true', async () => {
      const mockDbResponse = {
        rowCount: 1
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.delete('delete123', 'user123');

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining('UPDATE shares'),
        ['delete123', 'user123']
      );

      expect(result).toBe(true);
    });

    it('should return false when note not found or access denied', async () => {
      const mockDbResponse = {
        rowCount: 0
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.delete('nonexistent', 'user');

      expect(result).toBe(false);
    });
  });

  describe('exists', () => {
    it('should return true when note exists', async () => {
      const mockDbResponse = {
        rows: [{ id: 1 }]
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.exists('existing123');

      expect(result).toBe(true);
    });

    it('should return false when note does not exist', async () => {
      const mockDbResponse = {
        rows: []
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.exists('nonexistent');

      expect(result).toBe(false);
    });

    it('should return false on database error', async () => {
      mockQuery.mockRejectedValueOnce(new Error('Database error'));

      const result = await NoteModel.exists('test');

      expect(result).toBe(false);
    });
  });

  describe('getByOwner', () => {
    it('should return array of notes for owner', async () => {
      const mockDbResponse = {
        rows: [
          {
            id: 1,
            share_id: 'note1',
            content: '# Note 1',
            owner_id: 'user123',
            created_at: new Date('2024-01-01T00:00:00Z'),
            updated_at: new Date('2024-01-01T01:00:00Z'),
            version: 1,
            is_active: true
          },
          {
            id: 2,
            share_id: 'note2',
            content: '# Note 2',
            owner_id: 'user123',
            created_at: new Date('2024-01-01T00:30:00Z'),
            updated_at: new Date('2024-01-01T01:30:00Z'),
            version: 2,
            is_active: true
          }
        ]
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.getByOwner('user123');

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining('SELECT * FROM shares'),
        ['user123']
      );

      expect(result).toHaveLength(2);
      expect(result[0].shareId).toBe('note1');
      expect(result[1].shareId).toBe('note2');
    });

    it('should return empty array when no notes found', async () => {
      const mockDbResponse = {
        rows: []
      };

      mockQuery.mockResolvedValueOnce(mockDbResponse);

      const result = await NoteModel.getByOwner('user123');

      expect(result).toEqual([]);
    });
  });
});